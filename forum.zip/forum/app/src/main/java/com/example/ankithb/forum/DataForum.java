package com.example.ankithb.forum;

/**
 * Created by Ankith B on 20-12-2017.
 */

public class DataForum {

    public String f1;
    public String f2;
    public String f3;
    public String f4;
    public String f5;
}
